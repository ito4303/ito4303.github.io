# このデータについて

このディレクトリに含まれるデータは、[いしかわオープンデータカタログ](https://front.opendata.pref.ishikawa.lg.jp)の[石川県クマ出没データ](https://ckan.opendata.pref.ishikawa.lg.jp/dataset/bear_incidents_data)から取得したものです。

これらデータは、[石川県](https://www.pref.ishikawa.lg.jp/)が[Creative Commons Attribution](https://opendefinition.org/licenses/cc-by/)ライセンスで公開しているものです。
